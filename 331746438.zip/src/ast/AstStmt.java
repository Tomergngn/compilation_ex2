package ast;

public abstract class AstStmt extends AstNode
{
}
