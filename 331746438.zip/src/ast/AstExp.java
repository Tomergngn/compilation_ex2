package ast;

public abstract class AstExp extends AstNode
{
}